-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2017 at 01:17 PM
-- Server version: 5.5.54-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `visibility` tinyint(4) NOT NULL DEFAULT '0',
  `allow_comment` tinyint(4) NOT NULL DEFAULT '0',
  `allow_ads` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `ordering`, `visibility`, `allow_comment`, `allow_ads`) VALUES
(2, 'Galaxy', 'Samsung ', 3, 1, 0, 1),
(3, 'private', 'this is private', 3, 1, 1, 1),
(5, 'iphone', 'Apple Divice', 2, 0, 1, 0),
(7, 'Tecno', ' C9 blus', 5, 0, 1, 0),
(8, 'HTC', 'NEW', 9, 0, 1, 1),
(9, 'ooo', 'lll', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `stat` tinyint(4) NOT NULL,
  `date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_comment` (`item_id`),
  KEY `user_comment` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `comment`, `stat`, `date`, `item_id`, `user_id`) VALUES
(4, 'mmmmmmmmmm', 0, '2017-04-05', 3, 1),
(5, '                                kjgffbbhuigbffvguhbdgnkicghvbrhgbcnjdhbfc jkdfnbc fbcjsefbcj vsjhgc vwehjcxbsdufbgceurfcgfwuycsdnckdbgfbcye  \r\nmoscgjfdnbkldfmb,dbm,vgngfnfg\r\nngflnmgflnmlfgnfnf\r\nngf\r\nnfg\r\nn\r\nfgn\r\n\r\n\r\n\r\nnfgngfnfgnmfmnmn\r\n                          ', 0, '2017-04-19', 2, 13);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `add_date` date NOT NULL,
  `country_made` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stat` int(11) NOT NULL,
  `rating` smallint(6) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `descrip` text NOT NULL,
  `approve` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_1` (`member_id`),
  KEY `cat_1` (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `add_date`, `country_made`, `image`, `stat`, `rating`, `cat_id`, `member_id`, `descrip`, `approve`) VALUES
(2, 'gta1', '$10', '2017-04-14', 'USA', '', 4, 0, 5, 16, 'very good', 1),
(3, 'ps4', '10', '2017-04-14', 'ds', '', 1, 0, 5, 3, 'games', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'to id user',
  `username` varchar(255) NOT NULL COMMENT 'user to login',
  `password` varchar(255) NOT NULL COMMENT 'password to login',
  `email` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `groupID` int(11) NOT NULL DEFAULT '0' COMMENT 'id user group',
  `trusstatus` int(11) NOT NULL DEFAULT '0' COMMENT 'seller raank',
  `regstatus` int(11) NOT NULL DEFAULT '0' COMMENT 'user provel',
  `date` date NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `email`, `fullname`, `groupID`, `trusstatus`, `regstatus`, `date`) VALUES
(1, 'yaseen', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'yaseeno373@gmail.com', 'yaseen omar', 1, 0, 1, '0000-00-00'),
(3, 'omar', 'a9993e364706816aba3e25717850c26c9cd0d89d', '', 'omar yousif', 1, 0, 1, '0000-00-00'),
(13, 'osman', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'as@', 'os ali', 0, 0, 1, '2017-04-08'),
(14, 'hady', 'fd2f2cbb142c27da92f49291a506e74d434bc063', 'fff', 'hhhh', 0, 0, 1, '2017-04-08'),
(15, 'dany', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jk', 'jjj', 0, 0, 0, '2017-04-08'),
(16, 'bahry', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'jjjj', 'km', 0, 0, 1, '2017-04-13');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `item_comment` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_comment` FOREIGN KEY (`user_id`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `cat_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `member_1` FOREIGN KEY (`member_id`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
